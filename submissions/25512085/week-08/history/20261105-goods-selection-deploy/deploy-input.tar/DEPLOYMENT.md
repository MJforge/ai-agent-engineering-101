# Goods selection deployment

Approved scope: fast-forward 5c5298a to 822ca8f (two commits: prior deployment evidence and goods-selection changes). No commit/push performed by deployment helper.

## Safety / rollback plan

- Verify clean affected paths, Git-blob SHA256 against LF remote files, existing guarded wrapper and 60-second watchdog before FF.
- Back up only seller.py and seller_cash_policy.json. No production state, inventory, credentials, environment, crontab, or original launcher read/copied.
- Before seller signal, any failure leaves old seller runtime running. If restoration becomes necessary, copy the two verified backup files individually over their original paths; never reset/rewrite Git history. Report the resulting intentionally dirty files. Do not blindly retry or signal after a failure.
- Exactly one SIGTERM to verified seller PID, with identity/starttime/parentage checks. Existing watchdog restarts seller. Kit, buyer, tunnel, pane and VM are not restarted. In-flight in-memory negotiations may be lost.
- Tests run from a unique isolated tracked-code archive, excluding live untracked state/keys; socket audit blocks external connections. Synthetic test output retained verbatim in new log files.
- Only board and local/existing registered public card GETs. No registration, negotiation, checkout, posting, or test trades.

Results pending; authoritative per-phase JSON and synthetic logs are saved alongside this file.
